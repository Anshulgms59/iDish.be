<?php
require __DIR__ . '/vendor/autoload.php';

use Google\Cloud\Vision\V1\Client\ImageAnnotatorClient;
use Google\Cloud\Vision\V1\Image;
use Google\Cloud\Vision\V1\Feature;
use Google\Cloud\Vision\V1\AnnotateImageRequest;
use Google\Cloud\Vision\V1\BatchAnnotateImagesRequest;

// Set Google Cloud credentials
putenv('GOOGLE_APPLICATION_CREDENTIALS=C:\xampp\htdocs\vision\v\idishnew.json'); // Update with your credentials file

// Function to process the image and get the dish name using Google Vision API
function getDishName($imageData) {
    $client = new ImageAnnotatorClient();
    $image = (new Image())->setContent($imageData);
    $feature = (new Feature())->setType(Feature\Type::WEB_DETECTION);
    
    $request = (new AnnotateImageRequest())
        ->setImage($image)
        ->setFeatures([$feature]);

    $batchRequest = new BatchAnnotateImagesRequest();
    $batchRequest->setRequests([$request]);
    $response = $client->batchAnnotateImages($batchRequest);

    $webDetection = $response->getResponses()[0]->getWebDetection();
    
    $dishName = "Unknown";
    if ($webDetection && $webDetection->getWebEntities()) {
        foreach ($webDetection->getWebEntities() as $entity) {
            if (!empty($entity->getDescription())) {
                $dishName = htmlspecialchars($entity->getDescription());
                break; // Take the first relevant result
            }
        }
    }
    
    $client->close();
    return $dishName;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dishName = "Unknown";
    
    if (isset($_FILES['image'])) {
        // If an image is uploaded through file input
        $imageTmpPath = $_FILES['image']['tmp_name'];
        $imageData = file_get_contents($imageTmpPath);
        $dishName = getDishName($imageData);
    }
    
    if (isset($_POST['image']) && !empty($_POST['image'])) {
        // If a Base64 image is received from the camera
        $imageData = $_POST['image'];
        $imageData = str_replace('data:image/jpeg;base64,', '', $imageData); // Clean up Base64 string
        $imageData = base64_decode($imageData); // Decode Base64 image
        $dishName = getDishName($imageData);
    }

    echo json_encode(['dishName' => $dishName]);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Capture and Identify Dish</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        #camera, #canvas {
            display: none;
        }
        video {
            width: 100%;
            max-width: 500px;
        }
        canvas {
            display: none;
        }
    </style>
</head>
<body>
    <h2>Capture or Upload an Image to Identify a Dish</h2>
    <form id="captureForm" method="post" enctype="multipart/form-data">
        <div>
            <input type="file" name="image" accept="image/*" id="fileInput" style="margin-left: 5px;">
            <p>Or</p>
            <button type="button" id="openCameraBtn" style="margin-left: 15px;"><i class="fa fa-camera"></i> Capture Photo</button>
        </div>

        <!-- Camera Video Feed -->
        <div id="camera">
            <video id="video" autoplay></video>
            <button type="button" id="captureBtn">Capture</button>
            <canvas id="canvas"></canvas>
            <input type="hidden" name="image" id="capturedImage">
        </div>

        <button type="button" id="uploadBtn">Upload and Detect</button>
    </form>

    <h3>Detected Dish:</h3>
    <p id="dishResult">Waiting for photo...</p>

    <script>
        const openCameraBtn = document.getElementById('openCameraBtn');
        const cameraDiv = document.getElementById('camera');
        const video = document.getElementById('video');
        const captureBtn = document.getElementById('captureBtn');
        const canvas = document.getElementById('canvas');
        const fileInput = document.getElementById('fileInput');
        const capturedImageInput = document.getElementById('capturedImage');
        const uploadBtn = document.getElementById('uploadBtn');
        const dishResult = document.getElementById('dishResult');

        // Open camera when the "Capture Photo" button is clicked
        openCameraBtn.addEventListener('click', async () => {
            fileInput.style.display = 'none';
            cameraDiv.style.display = 'block';
            
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true });
                video.srcObject = stream;
            } catch (err) {
                console.error('Error accessing the camera: ', err);
                alert('Could not access camera.');
            }
        });

        // Capture the photo and show it on canvas
        captureBtn.addEventListener('click', () => {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            context.drawImage(video, 0, 0, canvas.width, canvas.height);

            const dataURL = canvas.toDataURL('image/jpeg');
            capturedImageInput.value = dataURL;

            cameraDiv.style.display = 'none';
            fileInput.style.display = 'block';
        });

        // Handle form submission via AJAX to send captured image to the server
        uploadBtn.addEventListener('click', async () => {
            const formData = new FormData();
            const imageBase64 = capturedImageInput.value;

            // Send the Base64 image to the server
            const response = await fetch(window.location.href, {
                method: 'POST',
                body: new URLSearchParams({ image: imageBase64 })
            });

            const data = await response.json();
            if (data.dishName) {
                dishResult.textContent = `Detected Dish: ${data.dishName}`;
            } else {
                dishResult.textContent = "No dish detected.";
            }
        });
    </script>
</body>
</html>
