<?php
require __DIR__ . '/vendor/autoload.php';

use Google\Cloud\Vision\V1\Client\ImageAnnotatorClient;
use Google\Cloud\Vision\V1\Image;
use Google\Cloud\Vision\V1\Feature;
use Google\Cloud\Vision\V1\AnnotateImageRequest;
use Google\Cloud\Vision\V1\BatchAnnotateImagesRequest;

putenv('GOOGLE_APPLICATION_CREDENTIALS=C:\xampp\htdocs\vision\v\idishnew.json'); // Update with your credentials file

// Google Places API Key
$googlePlacesAPIKey = 'AIzaSyC5zdCNSYZMqOf89qVIKir4MKXcRsOjwww'; // Replace with your Google Places API key

$imagePath = ''; // To hold the path of the uploaded image
$dishName = '';  // This will store the detected dish name

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $imageTmpPath = $_FILES['image']['tmp_name'];
    $imageData = file_get_contents($imageTmpPath);

    // Create a unique file name and save the uploaded image to a directory
    $imagePath = 'uploads/' . uniqid('image_', true) . '.' . pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    if (!is_dir('uploads')) {
        mkdir('uploads', 0777, true); // Create 'uploads' directory if it doesn't exist
    }
    move_uploaded_file($imageTmpPath, $imagePath);

    // Use Google Vision API to detect dish name
    $client = new ImageAnnotatorClient();
    $image = (new Image())->setContent($imageData);

    // Add Web Detection Feature
    $webDetectionFeature = (new Feature())->setType(Feature\Type::WEB_DETECTION);

    // Prepare the request with Web Detection
    $request = (new AnnotateImageRequest())
        ->setImage($image)
        ->setFeatures([$webDetectionFeature]);

    $batchRequest = new BatchAnnotateImagesRequest();
    $batchRequest->setRequests([$request]);
    $response = $client->batchAnnotateImages($batchRequest);

    // Process the Web Detection results to get the dish name
    $webDetectionResult = $response->getResponses()[0]->getWebDetection();
    if ($webDetectionResult) {
        $webEntities = $webDetectionResult->getWebEntities();
        if ($webEntities && count($webEntities) > 0) {
            foreach ($webEntities as $entity) {
                if (!empty($entity->getDescription())) {
                    $dishName = htmlspecialchars($entity->getDescription());
                    break; // Take the first relevant result
                }
            }
        }
    }

    $client->close();
}

// If dish name is found, fetch restaurants
if (!empty($dishName)) {
    $city = "San Francisco"; // You can change this to use dynamic geolocation
    $placesApiUrl = "https://maps.googleapis.com/maps/api/place/textsearch/json?query=restaurants+serving+" . urlencode($dishName) . "+in+" . urlencode($city) . "&key=" . $googlePlacesAPIKey;

    // Fetch the data from Google Places API
    $response = file_get_contents($placesApiUrl);
    $responseData = json_decode($response, true);

    $restaurants = [];
    if (isset($responseData['results'])) {
        foreach ($responseData['results'] as $index => $restaurant) {
            $restaurants[] = [
                'id' => $index + 1,  // Numeric ID for QR Code (using loop index as unique numeric ID)
                'name' => htmlspecialchars($restaurant['name']),
                'address' => htmlspecialchars($restaurant['formatted_address']),
                'rating' => isset($restaurant['rating']) ? $restaurant['rating'] : 'N/A',
                'lat' => $restaurant['geometry']['location']['lat'],
                'lng' => $restaurant['geometry']['location']['lng'],
                'website' => isset($restaurant['website']) ? $restaurant['website'] : 'No website available'
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Image for Dish Detection and Fetch Restaurants</title>
    
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC5zdCNSYZMqOf89qVIKir4MKXcRsOjwww&callback=initMap&libraries=&v=weekly" async></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

    <script>
        let map;
        let markers = [];

        function initMap() {
            const center = { lat: 37.7749, lng: -122.4194 }; // San Francisco

            map = new google.maps.Map(document.getElementById("map"), {
                center: center,
                zoom: 12,
            });

            const restaurants = <?php echo json_encode($restaurants); ?>;
            restaurants.forEach(restaurant => {
                const marker = new google.maps.Marker({
                    position: { lat: restaurant.lat, lng: restaurant.lng },
                    map: map,
                    title: restaurant.name,
                });

                const infoWindowContent = `
                    <div>
                        <strong>${restaurant.name}</strong><br>
                        ${restaurant.address}<br>
                        Rating: ${restaurant.rating}<br>
                        Website: <a href="${restaurant.website}" target="_blank">${restaurant.website}</a><br>
                        <strong>QR Code:</strong><br>
                        <div id="qrcode_${restaurant.id}" style="width: 100px; height: 100px;"></div>
                    </div>
                `;

                const infoWindow = new google.maps.InfoWindow({
                    content: infoWindowContent
                });

                marker.addListener("click", () => {
                    infoWindow.open(map, marker);
                });

                markers.push(marker);

                // Generate the QR code immediately for each restaurant
                generateQRCode(restaurant);
            });
        }

        function generateQRCode(restaurant) {
            const qrElement = document.getElementById(`qrcode_${restaurant.id}`);
            if (qrElement) {
                qrElement.innerHTML = '';
                new QRCode(qrElement, {
                    text: `Name: ${restaurant.name}\nAddress: ${restaurant.address}\nRating: ${restaurant.rating}\nWebsite: ${restaurant.website}`,
                    width: 100,
                    height: 100
                });
            }
        }
    </script>
</head>
<body>
    <h2>Upload or Take a Photo to Identify the Dish and Find Restaurants</h2>
    
    <form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="image" accept="image/*" capture="camera" required>
        <button type="submit">Upload and Detect</button>
    </form>

    <div id="imagePreview"></div>

    <?php if (!empty($imagePath)): ?>
        <h3>Uploaded Image:</h3>
        <img src="<?php echo htmlspecialchars($imagePath); ?>" alt="Uploaded Image" style="max-width: 500px; max-height: 500px;"><br>

        <h3>Detected Dish Name:</h3>
        <p><?php echo $dishName ?: 'No dish detected.'; ?></p>

        <?php if (!empty($restaurants)): ?>
            <h3>Restaurants serving <?php echo htmlspecialchars($dishName); ?> in San Francisco:</h3>
            <ul>
                <?php foreach ($restaurants as $restaurant): ?>
                    <li>
                        <strong><?php echo $restaurant['name']; ?></strong><br>
                        Address: <?php echo $restaurant['address']; ?><br>
                        Rating: <?php echo $restaurant['rating']; ?><br>
                        Website: <a href="<?php echo $restaurant['website']; ?>" target="_blank"><?php echo $restaurant['website']; ?></a><br>
                        <strong>QR Code:</strong><br>
                        <div id="qrcode_<?php echo $restaurant['id']; ?>" style="width: 100px; height: 100px;"></div><br>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php elseif (!empty($dishName)): ?>
            <p>No restaurants found for the dish "<?php echo htmlspecialchars($dishName); ?>" in San Francisco.</p>
        <?php endif; ?>
    <?php endif; ?>

    <div id="map" style="height: 500px; width: 100%;"></div>
</body>
</html>
