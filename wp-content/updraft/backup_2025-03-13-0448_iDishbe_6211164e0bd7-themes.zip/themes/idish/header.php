<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid px-lg-4">

        <?php if (has_custom_logo()) {
            the_custom_logo();
        } else { ?>
            <a class="navbar-brand" href="<?php echo home_url(); ?>">Idish</a>
        <?php } ?>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <?php
                wp_nav_menu(array(
                    'theme_location'  => 'primary',
                    'container'       => 'div',
                    'container_class' => 'collapse navbar-collapse',
                    'container_id'    => 'navbarNav',
                    'menu_class'      => 'navbar-nav ', // ms-auto
                    'fallback_cb'     => '__return_false',
                    'depth'           => 2,
                    'walker'          => new WP_Bootstrap_Navwalker()
                ));
            ?>

        </div>
        <div class="d-flex">
            <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
            <?php if (is_user_logged_in()) : 
                    $current_user = wp_get_current_user();
                    $avatar = get_avatar($current_user->ID, 32); // Get user avatar (32px size)
                ?>
                    <div class="dropdown">
                        <button class="btn btn-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo $avatar; ?> <?php echo esc_html($current_user->display_name); ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-dark">
                            <li><a class="dropdown-item" href="<?php echo esc_url(get_edit_profile_url($current_user->ID)); ?>">Profile</a></li>
                            <li><a class="dropdown-item" href="<?php echo esc_url(wp_logout_url(home_url())); ?>">Logout</a></li>
                        </ul>
                    </div>
                <?php else : ?>
                    <button type="button" class="btn btn-primary ms-1" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        <i class="fa fa-user"></i> Sign In
                    </button>
                <?php endif; ?>

        </div>


  </div>
</nav>


<!-- Sign In Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded-0">
      <div class="modal-header">
        <h5 class="modal-title fs-5" id="staticBackdropLabel">Sign In</h5>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form class="p-3 small">
          <div class="form-row mb-3">
            <div class="col">
              <input type="text" class="form-control shadow-none" placeholder="Username or Email" id="username">
            </div>
          </div>
          <div class="form-row mb-3">
            <div class="col">
              <input type="password" class="form-control shadow-none" placeholder="Password" id="password">
            </div>
          </div>
          <div class="d-flex justify-content-between mb-4">
            <div><small>Don't have an account? <a href="#" id="idishSignUpBtn">Sign Up</a></small></div>
            <div><small><a href="#" id="idishForgotBtn">Forgot Password</a></small></div>
          </div>
          <div class="form-row mt-2">
            <div class="col text-center">
              <button class="btn btn-success" type="submit" name="signIn">Sign In</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Sign Up Modal -->
<div class="modal fade" id="idishSignUp" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="signUpLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded-0">
      <div class="modal-header">
        <h5 class="modal-title fs-5" id="signUpLabel">Sign Up</h5>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form class="p-3 small">
          <div class="form-row mb-3">
            <div class="col">
              <input type="text" class="form-control shadow-none" placeholder="Full Name">
            </div>
          </div>
          <div class="form-row mb-3">
            <div class="col">
              <input type="email" class="form-control shadow-none" placeholder="Email">
            </div>
          </div>
          <div class="form-row mb-3">
            <div class="col">
              <input type="text" class="form-control shadow-none" placeholder="Username">
            </div>
          </div>
          <div class="form-row mb-3">
            <div class="col">
              <input type="password" class="form-control shadow-none" placeholder="Password">
            </div>
          </div>
          <div class="form-row mb-3">
            <div class="col">
              <input type="password" class="form-control shadow-none" placeholder="Confirm Password">
            </div>
          </div>
          <div class="d-flex justify-content-between mb-4">
            <div><small>Already have an account? <a href="#" id="idishSignInBtn">Sign In</a></small></div>
          </div>
          <div class="form-row mt-2">
            <div class="col text-center">
              <button class="btn btn-success" type="submit" name="signUp" id="signUp">Sign Up</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Forgot Password Modal -->
<div class="modal fade" id="idishForgot" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="forgotLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded-0">
      <div class="modal-header">
        <h5 class="modal-title fs-5" id="forgotLabel">Forgot Password</h5>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form class="p-3 small">
          <div class="form-row mb-3">
            <div class="col">
              <input type="email" class="form-control shadow-none" placeholder="Enter your email address">
            </div>
          </div>
          <div class="form-row mt-2">
            <div class="col text-center">
              <button class="btn btn-success" type="submit" name="submit" id="resetBtn">Reset Password</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
      jQuery(document).ready(function($){

        // Show Sign In Modal when clicking Sign In button
        $('#idishSignInBtn').click(function(e){
            e.preventDefault();
            $('#staticBackdrop').modal('show');
            $('#idishSignUp').modal('hide');
            $('#idishForgot').modal('hide');
        });

        // Show Sign Up Modal when clicking Sign Up button
        $('#idishSignUpBtn').click(function(e){
            e.preventDefault();
            $('#idishSignUp').modal('show');
            $('#staticBackdrop').modal('hide');
            $('#idishForgot').modal('hide');
        });

        // Show Forgot Password Modal when clicking Forgot Password button
        $('#idishForgotBtn').click(function(e){
            e.preventDefault();
            $('#idishForgot').modal('show');
            $('#staticBackdrop').modal('hide');
            $('#idishSignUp').modal('hide');
        });


        $('#signIn').click(function(e){
            e.preventDefault();
         
         var username = $('#username').val();
         var password = $('#password').val();
              

        })


function showMessage(message, messageType, popupID) {
    // Determine the correct class based on message type
    let alertClass = '';
    if (messageType === 'success') {
        alertClass = 'alert-success';  // Green for success
    } else if (messageType === 'error') {
        alertClass = 'alert-danger';   // Red for errors
    } else if (messageType === 'warning') {
        alertClass = 'alert-warning';  // Yellow for warnings
    } else {
        alertClass = 'alert-info';     // Default info color (blue)
    }

    // Inject the message with the appropriate alert class
    $('#msg_div_' + popupID).html(
        `<div class="alert ${alertClass} alert-dismissible fade show" role="alert">
            <strong>${messageType.charAt(0).toUpperCase() + messageType.slice(1)}!</strong> ${message}.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>`
    );
}




    });
</script>


</header>
