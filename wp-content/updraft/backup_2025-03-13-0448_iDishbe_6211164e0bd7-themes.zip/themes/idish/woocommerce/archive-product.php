<?php
get_header();
?>

<div class="container-fluid idish-shop-container">
	<div class="container py-lg-5">
		 <h1><?php // woocommerce_page_title(); ?></h1>
		<?php woocommerce_content(); ?>
	</div>
</div>

<?php
get_footer();
?>
