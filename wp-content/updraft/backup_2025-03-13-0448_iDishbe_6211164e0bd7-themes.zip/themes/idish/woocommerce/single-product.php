<?php
get_header();
?>

<div class="container-fluid idish-single-product">
    <div class="container py-lg-4">
         <?php woocommerce_content(); ?>
    </div>
</div>

<?php
get_footer();
?>
