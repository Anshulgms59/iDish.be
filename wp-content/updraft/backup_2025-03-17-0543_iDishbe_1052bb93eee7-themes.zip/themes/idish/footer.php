<footer class="bg-dark text-white text-center p-3">
    <p>&copy; <?php echo date('Y'); ?> Idish. All rights reserved.</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
