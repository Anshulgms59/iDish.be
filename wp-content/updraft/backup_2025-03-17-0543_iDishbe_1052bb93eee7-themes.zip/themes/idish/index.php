<?php get_header(); ?>
<div class="container mt-5">
    <h1>Welcome to Idish Theme</h1>
    <p>This is the main theme template.</p>
</div>
<?php get_footer(); ?>