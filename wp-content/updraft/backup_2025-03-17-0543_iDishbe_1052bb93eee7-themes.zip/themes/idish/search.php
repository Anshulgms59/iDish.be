<?php get_header();

global $wp_query;

?>


<?php get_footer();
