<?php get_header(); ?>
  
<?php
echo do_shortcode('[food_dish_finder]');
?>

<?php get_footer(); ?>







