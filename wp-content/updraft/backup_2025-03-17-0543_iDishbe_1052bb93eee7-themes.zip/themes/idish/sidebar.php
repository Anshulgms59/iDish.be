<aside>
    <?php dynamic_sidebar('sidebar-1'); ?>
</aside>
