<?php

use Google\Cloud\Core\Testing\TestHelpers;

TestHelpers::requireKeyfile('GOOGLE_CLOUD_PHP_TESTS_KEY_PATH');
